#ifndef DSAP_DIRECTION_TYPE_H
#define DSAP_DIRECTION_TYPE_H

enum class DirectionType {
    kForward,
    kLeft,
    kRight,
};

#endif //DSAP_DIRECTION_TYPE_H
