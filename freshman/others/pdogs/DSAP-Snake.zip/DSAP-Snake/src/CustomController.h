#ifndef DSAP_CUSTOM_CONTROLLER_H
#define DSAP_CUSTOM_CONTROLLER_H

#include "ISnakeController.h"

#include <vector>
#include <random>
using namespace std;
class CustomController : public ISnakeController {
public:
    explicit CustomController() :
        _final_angle { 0 },
        _turnDirection { DirectionType::kRight },
        _currentDirType { DirectionType::kForward },
        _dirSymbol { AngleToSymbol(_final_angle) } {}
    DirectionType NextDirection(const Game&, size_t) override;
private:
    enum class DirectionSymbol {
        RIGHT, DOWN, LEFT, UP, NONE
    };
    DirectionType _turnDirection;
    DirectionType _currentDirType;
    float _final_angle;
    DirectionSymbol _dirSymbol;
    const float turn_radius =  3 * 180 / 3.1415926 + 30;
	bool turningDifferentDirection = true;
	vector<DirectionType> directionChooseByfood = {DirectionType::kRight, DirectionType::kForward, DirectionType::kLeft};
    
	DirectionSymbol AngleToSymbol(float);
    float GetCollisionDistance(Position, DirectionSymbol, const Game&, size_t);
    float GetFrontCollisionDistance(Position, float, DirectionSymbol, Position, float);
    float FrontWallDistance(Position, DirectionSymbol, float, float);
    float SelfBodyCollisionDistance(DirectionSymbol dirSymbol, const Game& game); 
    std::vector<DirectionType> choose_dir_by_food(Position Head, const Game& game, int head_dir);
    
    //bool mayGotTrap(Position, DirectionSymbol, float, float);
};

DirectionType CustomController::NextDirection(const Game& game, size_t id) {
    const auto& snake = game.Snakes().at(id);
 
 	// if is turning around
    // keep turning
    bool finishTurning = false;
    if (_currentDirType != DirectionType::kForward) {
        float remaining_angle = abs(_final_angle - snake.Direction());
        if (remaining_angle > 0) { //still turning
            return _currentDirType;
        }
        // finished turning
        _dirSymbol = AngleToSymbol(snake.Direction());
        finishTurning = true;
    }
 
    
	directionChooseByfood = choose_dir_by_food(snake.Head(), game, static_cast<int>(snake.Direction()));
	bool safe[3] = {1, 1, 1};

    float distance = GetCollisionDistance(snake.Head(), _dirSymbol, game, id);
	
    if (distance > 0 && distance < turn_radius) {
    	safe[0] = false;
    	//cout<<"front collide\n";
    }
    
	Position snakeHead = snake.Head();
	
	Position buffer;
	int r = 30;
	
	if (_dirSymbol == DirectionSymbol::LEFT) {
		buffer = {-r, -r};
	    float turningDirectionDistance = GetCollisionDistance(snake.Head() + buffer, DirectionSymbol::UP, game, id);
		if(turningDirectionDistance > 0 && turningDirectionDistance < turn_radius + 30){
	    	safe[1] = false;
	    	//cout<<"right collide\n";
		}
		buffer = {-r, r};
   		turningDirectionDistance = GetCollisionDistance(snake.Head() + buffer, DirectionSymbol::DOWN, game, id);
		if(turningDirectionDistance > 0 && turningDirectionDistance < turn_radius + 30){
	    	safe[2] = false;
	    	//cout<<"left collide when left\n";
		}
	}
	else if (_dirSymbol == DirectionSymbol::RIGHT) {
		buffer = {r, r};
	    float turningDirectionDistance = GetCollisionDistance(snake.Head() + buffer, DirectionSymbol::DOWN, game, id);
		if(turningDirectionDistance > 0 && turningDirectionDistance < turn_radius + 30) {
	    	safe[1] = false;
	    	//cout<<"right collide when right\n";
		}
		buffer = {r, -r};
   		turningDirectionDistance = GetCollisionDistance(snake.Head() + buffer, DirectionSymbol::UP, game, id);
		if(turningDirectionDistance > 0 && turningDirectionDistance < turn_radius + 30){
	    	safe[2] = false;
	    	//cout<<"left collide when right\n";
		}
	}
	else if (_dirSymbol == DirectionSymbol::UP) {
		buffer = {r, -r};
	    float turningDirectionDistance = GetCollisionDistance(snake.Head() + buffer, DirectionSymbol::RIGHT, game, id);
		if(turningDirectionDistance > 0 && turningDirectionDistance < turn_radius + 30){
	    	safe[1] = false;
	    	//cout<<"right collide when up\n";
		}
		buffer = {-r, -r};
   		turningDirectionDistance = GetCollisionDistance(snake.Head() + buffer, DirectionSymbol::LEFT, game, id);
		if(turningDirectionDistance > 0 && turningDirectionDistance < turn_radius + 30){
	    	safe[2] = false;
	    	//cout<<"left collide when up\n";
		}
	}
	else if (_dirSymbol == DirectionSymbol::DOWN) {
		buffer = {-r, r};
	    float turningDirectionDistance = GetCollisionDistance(snake.Head() + buffer, DirectionSymbol::LEFT, game, id);
		if(turningDirectionDistance > 0 && turningDirectionDistance < turn_radius + 30){
	    	safe[1] = false;
	    	//cout<<"right collide when down\n";
		}
		buffer = {r, r};
	    turningDirectionDistance = GetCollisionDistance(snake.Head() + buffer, DirectionSymbol::RIGHT, game, id);
		if(turningDirectionDistance > 0 && turningDirectionDistance < turn_radius + 30){
	    	safe[2] = false;
	    	//cout<<"left collide when down\n";
		}
	}
	
	//for(int i=0;i<3;i++) cout<<safe[i]<<" ";
	//cout<<"\n";

	/*if(!safe[1] && safe[2]){
		_currentDirType = DirectionType::kLeft;
		_final_angle = snake.Direction() - 90;
		return _currentDirType;
	}
	else if(!safe[2] && safe[1]){
		_currentDirType = DirectionType::kRight;
		_final_angle = snake.Direction() + 90;
		return _currentDirType;
	}*/

	
    for(int i = 0; i < 3; i++){
    	if(directionChooseByfood[i] == DirectionType::kForward){
    		if(safe[0]){
    			_currentDirType = DirectionType::kForward;
    			break;
			}
		}
		else if(directionChooseByfood[i] == DirectionType::kRight){
			if(safe[1]){
				_currentDirType = DirectionType::kRight;
				_final_angle = snake.Direction() + 90;
				break;
			}	
		}
		else{
			if(safe[2]){
				_currentDirType = DirectionType::kLeft;
				_final_angle = snake.Direction() - 90;
				break;
			}
			
		}
	}
	/*
	if(_dirSymbol == DirectionSymbol::RIGHT) cout<<"RIGHT\n";
	else if(_dirSymbol == DirectionSymbol::LEFT) cout<<"LEFT\n";
	else if(_dirSymbol == DirectionSymbol::DOWN) cout<<"DOWN\n";
	else if(_dirSymbol == DirectionSymbol::UP) cout<<"UP\n";
    cout<<"--------------------------------\n";
    */
    return _currentDirType;
}

vector<DirectionType> CustomController::choose_dir_by_food(Position Head, const Game& game, int head_dir){ 		//true: safe direction
	int food_sum[3] = {0};
	double cos45 = 1/sqrt(2);
	double cos30 = sqrt(3)/2;
	vector<DirectionType> d = {DirectionType::kRight, DirectionType::kForward, DirectionType::kLeft};
	Position u = {1, 0};		//face right
	head_dir %= 360;
	head_dir += 360;
	head_dir %= 360;
	if(head_dir <= 90) u = {0, 1};		//face down	
	else if(head_dir <= 180) u = {-1, 0};	//face left
	else if(head_dir <= 270) u = {0, -1};	   //face up
	int index = 3;
	for(auto& food : game.Foods()){
		Position v = food.position - Head;
		double cos = u.InnerProduct(v) / v.Length();
		index = 3;
		if(cos30 < cos && cos < 1){		//forward
			index = 1;
		}else if(-1 < cos && cos < cos45){
			if(v.x * u.y < 0) index = 0;		//right
			else index = 2;				//left
		}
		if(index < 3){
			if(index == 1){
				if(v.Length() <= 600 && food.leftTime - static_cast<int>(v.x + v.y) > 0) food_sum[index]++;
			}else if(index == 0 || index == 2){
				if(v.Length() >= 50 && v.Length() <= 200 && food.leftTime - static_cast<int>(v.x + v.y) > 0) food_sum[index]++;	
			}
		}
	}		
	
	if(food_sum[0] < food_sum[1]){
		swap(food_sum[0], food_sum[1]);
		swap(d[0], d[1]);
	}
	if(food_sum[1] < food_sum[2]){
		swap(food_sum[1], food_sum[2]);
		swap(d[1], d[2]);
	}
	if(food_sum[0] < food_sum[1]){
		swap(food_sum[0], food_sum[1]);
		swap(d[0], d[1]);
	}
	return d;
}

float CustomController::GetCollisionDistance(Position snakePos, DirectionSymbol dirSymbol, const Game& game, size_t id) {
    
    // check front collision distance with field
    float distance = FrontWallDistance(snakePos, dirSymbol, game.FieldWidth(), game.FieldHeight());
    
    // check front collision distance with other snakes
    for (auto it = game.Snakes().begin(); it != game.Snakes().end(); ++it) {
        const size_t anotherID = it->first;
        const Snake& anotherSnake = it->second;
        if (anotherID == id) continue;

        float d = GetFrontCollisionDistance(snakePos, Game::kSnakeRadius, dirSymbol, anotherSnake.Head(), Game::kSnakeRadius);
        
        if (d > 0) {
            if (distance < 0)    distance = d;
            else {
                distance = std::min(distance, d);
            }
        }

        for (const Position& pos : anotherSnake.Body()) {
            float d_body = GetFrontCollisionDistance(snakePos, Game::kSnakeRadius, dirSymbol, pos, Game::kSnakeRadius);
            if (d_body > 0) {
                if (distance < 0)    distance = d_body;
                else {
                    distance = std::min(distance, d_body);
                }
            }
            
        }
        
    }
    return distance;
}

CustomController::DirectionSymbol CustomController::AngleToSymbol(float angle) {
    // if angle is not a multiple of 90
    if (int(angle) % 90 != 0) {
        angle = round(angle / 90) * 90;
    }
    // can be converted into 4 directions
    int dir = abs((static_cast<int>(angle) % 360 + 360) / 90);
    dir %= 4;
    return static_cast<DirectionSymbol>(dir);
}

float CustomController::GetFrontCollisionDistance(Position snakePos, float snakeRadius, DirectionSymbol dirSymbol, Position target, float targetRadius) {
	float distanceX = abs(snakePos.x - target.x) - snakeRadius - targetRadius;
    float distanceY = abs(snakePos.y - target.y) - snakeRadius - targetRadius;
    if (dirSymbol == DirectionSymbol::LEFT) {
        distanceX = snakePos.x - target.x - snakeRadius - targetRadius;
    }
    else if(dirSymbol == DirectionSymbol::RIGHT){
    	distanceX = -(snakePos.x - target.x) - snakeRadius - targetRadius;
	}
	else if (dirSymbol == DirectionSymbol::UP) {
        distanceY = snakePos.y - target.y - snakeRadius - targetRadius;
    }
    else if(dirSymbol == DirectionSymbol::DOWN){
    	distanceY = -(snakePos.y - target.y) - snakeRadius - targetRadius;
	}
    // if direction is Left/Right
    if (dirSymbol == DirectionSymbol::LEFT || dirSymbol == DirectionSymbol::RIGHT) {
        if (distanceY > 0) { // if will not hit target y, return -1
            return -1;
        }
        return distanceX;
    }

    // if direction is Up/Down
    if (dirSymbol == DirectionSymbol::UP || dirSymbol == DirectionSymbol::DOWN) {
        if (distanceX > 0) { // if will not hit target x, return -1
            return -1;
        }
        
        return distanceY;
    }

    return -1;
}

float CustomController::FrontWallDistance(Position snakeHead, DirectionSymbol dirSymbol, float rightWall, float downWall) {
    Position frontFieldCollisionPos{ 0, 0 };
    if (dirSymbol == DirectionSymbol::LEFT) {
        frontFieldCollisionPos.x = 0;
        frontFieldCollisionPos.y = snakeHead.y;
    }
    else if (dirSymbol == DirectionSymbol::RIGHT) {
        frontFieldCollisionPos.x = rightWall;
        frontFieldCollisionPos.y = snakeHead.y;
    }
    else if (dirSymbol == DirectionSymbol::UP) {
        frontFieldCollisionPos.x = snakeHead.x;
        frontFieldCollisionPos.y = 0;
    }
    else if (dirSymbol == DirectionSymbol::DOWN) {
        frontFieldCollisionPos.x = snakeHead.x;
        frontFieldCollisionPos.y = downWall;
    }
    
    return GetFrontCollisionDistance(snakeHead, Game::kSnakeRadius, dirSymbol, frontFieldCollisionPos, 0);

}

#endif // DSAP_CUSTOM_CONTROLLER_H
