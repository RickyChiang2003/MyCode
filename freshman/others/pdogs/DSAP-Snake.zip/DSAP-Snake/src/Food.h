#ifndef DSAP_FOOD_H
#define DSAP_FOOD_H

#include "Position.h"

struct Food {
    Position position;
    int leftTime;
};

#endif // DSAP_FOOD_H