#!/bin/bash
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color
# part 1 bfs
IFS=$' \n'
for i in `ls ./maps_full/p1`; do
    output=`python hw1-judge.py "./maps_full/p1/$i" --method bfs`
    answer=`cat ./answer/p1/$i`
    if [[ $output == $answer ]]; then
        echo -e "${GREEN}p1 $i bfs correct${NC}"
    elif [[ $output == "TLE" ]]; then
        echo -e "${RED}p1 $i bfs TLE${NC}"
    else
        echo -e "${RED}p1 $i bfs wrong${NC}"
    fi
done
# part 1 astar
for i in `ls ./maps_full/p1`; do
    output=`python hw1-judge.py "./maps_full/p1/$i" --method astar`
    answer=`cat ./answer/p1/$i`
    if [[ $output == $answer ]]; then
        echo -e "${GREEN}p1 $i astar correct${NC}"
    elif [[ $output == "TLE" ]]; then
        echo -e "${RED}p1 $i astar TLE${NC}"
    else
        echo -e "${RED}p1 $i astar wrong${NC}"
    fi
done

# # part 2 corner
for i in `ls ./maps_full/p2`; do
    output=`python hw1-judge.py "./maps_full/p2/$i" --method astar_corner`
    answer=`cat ./answer/p2/$i`
    if [[ $output == $answer ]]; then
        echo -e "${GREEN}p2 $i corner correct${NC}"
    elif [[ $output == "TLE" ]]; then
        echo -e "${RED}p2 $i corner TLE${NC}"
    else 
        echo -e "${RED}p2 $i corner wrong${NC}"
    fi
done

# part 3 multi
for i in `ls ./maps_full/p3`; do
    output=`python hw1-judge.py "./maps_full/p3/$i" --method astar_multi`
    answer=`cat ./answer/p3/$i`
    if [[ $output == $answer ]]; then
        echo -e "${GREEN}p3 $i multi correct${NC}"
    elif [[ $output == "TLE" ]]; then
        echo -e "${RED}p3 $i multi TLE${NC}"
    else 
        echo -e "${RED}p3 $i multi wrong${NC}"
    fi
done
