# HW1 test
put search.py here and run "sh run.sh"
