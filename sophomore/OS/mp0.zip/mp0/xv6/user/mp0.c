#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
# define MAX_LEN 128

//refer to ls.c


int get_occur(char* dir, char key){
    int occur = 0;
    for(int i = strlen(dir); i >= 0; i--)
	if(dir[i] == key) occur++;
    return occur;

}

void traverse(int fd, struct dirent flag, char* rootdir, char key, int* dir_numptr, int* file_numptr){
    while(read(fd, &flag, sizeof(flag)) == sizeof(flag)){
	if(flag.inum == 0) continue;//printf("flag.name = %s\n",flag.name);
	if(strcmp(flag.name, ".") == 0 || strcmp(flag.name, "..") == 0) continue;

	//get next file name
	char nextdir[MAX_LEN] = {0};
	int nextfd;
	struct dirent nextflag;
	struct stat nextst;
	strcpy(nextdir, rootdir);
	nextdir[strlen(rootdir)] = '/';
	for(int i = 0, nlen = strlen(nextdir), flen = strlen(flag.name); i < flen; i++)
	    nextdir[i+nlen] = flag.name[i];

	//print occurence
	int occur = get_occur(nextdir, key);
	printf("%s %d\n", nextdir, occur);

	//open next file
	if((nextfd = open(nextdir, 0)) < 0) {printf("you fucked up in open\n");return;}
	else if(fstat(nextfd, &nextst) < 0) {printf("you fucked up in fstat\n");return;}

	//add and traverse
	if(nextst.type == T_DIR){
	    (*dir_numptr)++;
	    traverse(nextfd, nextflag, nextdir, key, dir_numptr, file_numptr);
	}
	else if(nextst.type == T_FILE)
	    (*file_numptr)++;
	else {printf("you fucked up in st.type != {T_DIR or T_FILE}\n");return;}
    }
}


void child_bad_root(char rootdir[], int pipefd[]){
    printf("%s [error opening dir]\n", rootdir);
    char buf[MAX_LEN] = {0};
    buf[0] = '!';
    write(pipefd[1], buf, MAX_LEN);
    write(pipefd[1], buf, MAX_LEN);
}


int main(int argc, char *argv[]){
    if(argc != 3){printf("input error\n");return 0;}

    int pipefd[2] = {0};
    pipe(pipefd);
    int pid = fork();
    // child
    if(pid == 0){
	close(pipefd[0]);
	char buf[MAX_LEN] = {0};
	char rootdir[MAX_LEN] = {0}, key = 0;
	int dir_num = 0, file_num = 0, fd;
	struct dirent flag = {0};
	struct stat st;
	strcpy(rootdir, argv[1]);
	key = *(argv[2]);

	// bad root directory
	if((fd = open(rootdir, 0)) < 0)
	    child_bad_root(rootdir, pipefd);
	else if(fstat(fd, &st) < 0)
	    child_bad_root(rootdir, pipefd);
	else if(st.type != T_DIR)
	    child_bad_root(rootdir, pipefd);
	// good root directory
	else{
	    int occur = get_occur(rootdir, key);
	    printf("%s %d\n", rootdir, occur);
	    traverse(fd, flag, rootdir, key, &dir_num, &file_num);
	    buf[0] = dir_num + '!';  // dir_num <= 20
	    write(pipefd[1], buf, MAX_LEN);
	    buf[0] = file_num + '!'; // file_num <= 20
	    write(pipefd[1], buf, MAX_LEN);
	    buf[0] = 0;
	}
	write(pipefd[1], buf, MAX_LEN);
	exit(0);
    }

    // parent
    close(pipefd[1]);

    char buf[MAX_LEN] = {0};
    int dir_num = 0, file_num = 0;
    read(pipefd[0], buf, MAX_LEN);
    dir_num = ((int)buf[0])-(int)('!');
    memset(buf, 0, MAX_LEN);
    read(pipefd[0], buf, MAX_LEN);
    file_num = ((int)buf[0])-(int)('!');
    memset(buf, 0, MAX_LEN);
    printf("\n%d directories, %d files\n", dir_num, file_num);

    read(pipefd[0], buf, MAX_LEN);
    wait(&pid);


    exit(0);
}
